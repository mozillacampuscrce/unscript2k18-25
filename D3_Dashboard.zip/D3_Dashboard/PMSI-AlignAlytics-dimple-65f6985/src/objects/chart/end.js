    };
    // End dimple.chart

