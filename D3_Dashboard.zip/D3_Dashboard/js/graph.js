
// http://www.mocky.io/v2/59cdca001100001b02cccbf2
// https://ihhiklw9ae.execute-api.ap-southeast-1.amazonaws.com/devtest/
// http://www.mocky.io/v2/59cde04c1100008602cccc1a

//var test_json;

jQuery.ajax({
            url: "http://www.mocky.io/v2/59cde04c1100008602cccc1a",
            type: "GET",
            //dataType: "json",
            contentType: 'application/json; charset=utf-8',
            success: function(resultData) {
                //var myJSON = JSON.stringify(resultData);
                //var parseJson =  JSON.parse(myJSON);
                //console.log("Output :",myJSON);
				test_json = JSON.stringify(resultData)
				test_json = JSON.parse(test_json);
				//alert(test_json);
				//alert(test_json.Station);
                //console.log("Parsed Output :",parseJson);
                //plotGraph(resultData);
                //console.log("End Function1");

           },
            error : function(jqXHR, textStatus, errorThrown) {
            },

           timeout: 120000,
        });

//HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "*");
/*
$.getJSON('http://www.mocky.io/v2/59cdca001100001b02cccbf2', function(data){
    alert(data);
});
*/

//alert(document.getElementById("h").getAttribute("value"));
//alert(document.getElementById("h").getAttribute("value"));
function t(){
//d3.selectAll("svg > *").remove()
//d3.selectAll("force > *").remove()
//d3.selectAll("node > *").remove()
//d3.selectAll("link > *").remove()
//svg.parentNode.removeChild(svg);
//location.reload();


var w = window.innerWidth - 22;
var h = window.innerHeight - 22;
w = 1000;
h = 600;

//alert("Width: " + w + "Height: " + h);

var i = 0;
var arr;
/*
if (number == 1)
	arr = [100, 200, 300, 400, 500, 600];
else
	arr = [100, 200, 300, 400, 500, 700];
*/
// http://blog.thomsonreuters.com/index.php/mobile-patent-suits-graphic-of-the-day/
var links = [
  {source: "Virar", target: "Borivali", type: "licensing"},
  {source: "Borivali", target: "Andheri", type: "licensing"},
  {source: "Andheri", target: "Bandra", type: "licensing"},
  {source: "Bandra", target: "Dadar", type: "licensing"},
  {source: "Dadar", target: "Churchgate", type: "licensing"}
];
var width = w,
    height = h;
var nodes = {};
/*
var nodes = [{ x:   width/2, y: height/2 },
    { x: width/2, y: height/2 },
	{ x: width/2, y: height/4 }
	];
*/
	
// Compute the distinct nodes from the links.
links.forEach(function(link) {
  link.source = nodes[link.source] || (nodes[link.source] = {name: link.source});
  link.target = nodes[link.target] || (nodes[link.target] = {name: link.target});
});


//alert(d3.values(nodes));
var force = d3.layout.force()
    .nodes(d3.values(nodes))
    .links(links)
    .size([width, height])
    .linkDistance(100)
    .charge(-2000)
    .on("tick", tick)
    .start();

var svg = d3.select("#graph_test").append("svg")
    .attr("width", width)
    .attr("height", height);

var link = svg.selectAll(".link")
    .data(force.links())
  .enter().append("line")
    .attr("class", "link");

var node = svg.selectAll(".node")
    .data(force.nodes())
  .enter().append("g")
    .attr("class", "node")
    .on("mouseover", mouseover)
    .on("mouseout", mouseout);
    //.call(force.drag);


var h1 = document.getElementsByTagName("g")[0];
var att = document.createAttribute("id");
att.value = 0;
h1.setAttributeNode(att);

var h1 = document.getElementsByTagName("g")[1];
var att = document.createAttribute("id");
att.value = 1;
h1.setAttributeNode(att);

var h1 = document.getElementsByTagName("g")[2];
var att = document.createAttribute("id");
att.value = 2;
h1.setAttributeNode(att);

var h1 = document.getElementsByTagName("g")[3];
var att = document.createAttribute("id");
att.value = 3;
h1.setAttributeNode(att);

var h1 = document.getElementsByTagName("g")[4];
var att = document.createAttribute("id");
att.value = 4;
h1.setAttributeNode(att);

var h1 = document.getElementsByTagName("g")[5];
var att = document.createAttribute("id");
att.value = 5;
h1.setAttributeNode(att);


var m = 230, f = 20;
/*	
var tooltip = d3.select("#graph_test")
    .append("div")
    .style("position", "absolute")
    .style("z-index", "10")
    .style("visibility", "hidden")
    .text(m, f);
*/
/*
var node_id;
function test(){
$('g').mouseover(function() {
   //node_id = ;
   node_id = this.id;
   //alert(node_id);
   //return node_id;
});
return node_id;
	//node_id = hello;
	//alert(node_id);
}
*/
	var node_id;
node.append("circle")
   .attr("r", 28).on("mouseover", function(){
  
   
   $('g').mouseover(function() {
   node_id = this.id;
   tooltip = d3.select("#graph_test").append("div").style("position", "absolute")
    .style("z-index", "10")
    .style("visibility", "visible").text(test_json.Station[node_id]);
	//node_tes = test();
	//alert("tool " + node_id);
	//tooltip.text(test_json.Station[node_id]);
	return tooltip.style("visibility", "visible");
   });


	})
	.on("mousemove", function(){return tooltip.style("top",
    (d3.event.pageY-70)+"px").style("left",(d3.event.pageX+10)+"px");})
	.on("mouseout", function(){return tooltip.style("visibility", "hidden");});;

node.append("text")
    .attr("x", -15).attr("y", 40)
    .attr("dy", ".35px")
    .text(function(d) { return d.name; });
	
node.append("text")
    .attr("x", -8).attr("y", 3)
    .attr("dy", ".35px")
    .text(function(d) { 
		d.name = test_json.Station[i];
		i = i + 1;
		return d.name; 
		});
//alert(this.node().textContent);

function tick() {
  link
      .attr("x1", function(d) { return d.source.x; })
      .attr("y1", function(d) { return d.source.y; })
      .attr("x2", function(d) { return d.target.x; })
      .attr("y2", function(d) { return d.target.y; });

  node
      .attr("transform", function(d) { d.fixed = false; return "translate(" + d.x + "," + d.y + ")"; });
	  //text.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });
}

function mouseover() {
  d3.select(this).select("circle").transition()
      .duration(500).attr("r", 34);
  d3.select(this).select("text").transition()
      .duration(500).attr("y", 45);
  //var elementStyle = d3.select(this).select("circle").attr("r").style;
}

function mouseout() {
  d3.select(this).select("circle").transition()
      .duration(500).attr("r", 28);
  d3.select(this).select("text").transition()
      .duration(500).attr("y", 40);
}

//alert(arr[1]);
/*
function test_num(){
//alert(test_json.Station[i]);
return test_json.Station[i];
}
*/
}