from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient

client = MongoClient('40.90.191.188',27017)

db = client['registration']


app = Flask(__name__)

@app.route('/login',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        dat = j["rollNo"]
        password = j["password"]
        tokenId = j["tokenId"]
        collection = db[dat]
        print(password)
        cursor = collection.find({}, {'_id': False})
        count = 0
        for i in cursor:
            if i["password"] == password:
                count += 1
                jdata = i
                jdata['tokenId'] = tokenId
                
        if count == 1:
            collection.remove( { } )
            jd = json.dumps(jdata)
            collection.insert(jdata)
            return jd
        else:
            jdat = {"status" : "wrong"}
            jd = json.dumps(jdat)
            return jd
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8012)
