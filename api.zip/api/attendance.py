from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient
#from flask_cors import CORS
client = MongoClient('40.90.191.188',27017)
import boto3
db = client['attendence']

ses = boto3.client('ses',aws_access_key_id='AKIAISABTY7CD4SIBQRQ',
    aws_secret_access_key='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',region_name='us-west-2')
sns = boto3.client('sns',aws_access_key_id='AKIAISABTY7CD4SIBQRQ',
    aws_secret_access_key='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',region_name='us-west-2')
app = Flask(__name__)
#CORS(app)


def notify(number,email,sub,per):
        ses.send_email(
    Source="nikhil161096@gmail.com",
    Destination={
        'ToAddresses': [
            email
        ]
    },
    Message={
        'Subject': {
            'Data': 'Success',
            'Charset': 'UTF-8'
        },
        'Body': {
            'Text': {
                'Data': 'Your pupil has registered for defaulter in: '+sub+'. The Attendence in that subject is '+str(per),
                'Charset': 'UTF-8'
            }
        }
    }
    )
        
        sns.publish( PhoneNumber= '+91'+number,
    Message='Your pupil has registered for defaulter in: '+sub+'. The Attendence in that subject is '+str(per),
    Subject='Sucess',
    MessageStructure='string',
    )




@app.route('/attendence',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        dat = j["rollNo"]
        collection = db[dat]
        db.collection_names(include_system_collections=False)
        
        cursor = collection.find({}, {'_id': False})
        count = 0
        bdaCount = 0
        ccCount = 0
        snmrCount = 0
        csmCount = 0
        attJson = []
        for i in cursor:
            count += 1
            attJson.append(i)
            if i['bda'] == "p":
                bdaCount += 1
            if i['cc'] == "p":
                ccCount += 1
            if i['snmr'] == "p":
                snmrCount += 1
            if i['ds'] == "p":
                csmCount += 1
        print(bdaCount,ccCount,snmrCount,csmCount,count)
        
        finalJson = {"bda" : bdaCount, "cc" : ccCount, "snmr" : snmrCount, "ds" : csmCount, "total" : count, "all" : attJson}
        jd = json.dumps(finalJson)
        if int((bdaCount/count)*100) <= 65:
            bdaPer = int((bdaCount/count)*100)
            notify('7709804055','nikhil161096@gmail.com','bda',bdaPer)
        elif int((ccCount/count)*100) <= 65:
            ccPer = int((ccCount/count)*100)
            notify('7709804055','nikhil161096@gmail.com','cc',ccPer)
        elif int((snmrCount/count)*100) <= 65:
            snmrPer = int((snmrCount/count)*100)
            notify('7709804055','nikhil161096@gmail.com','snmr',snmrPer)
        elif int((csmCount/count)*100) <= 65:
            csmPer = int((csmCount/count)*100)
            notify('7709804055','nikhil161096@gmail.com','csm',csmPer)
        return jd
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8016)
