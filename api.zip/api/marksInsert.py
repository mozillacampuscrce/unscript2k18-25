from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('40.90.191.188',27017)

db = client['attendence']


@app.route('/marksInsert',methods = ['POST', 'GET'])
def register():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        rollNo = j['rollNo']
        result = j['result']
        bda = j['bda']
        snmr = j['snmr']
        ds = j['ds']
        cc = j['cc']
        
        if result == "ut1":
            db = client["ut1_result"]
        elif result == "ut2":
            db = client["ut2_result"]
        else:
            db = client["sem_result"]
        val = { "bda" : bda, "cc" : cc , "ds" : ds, "snmr" : snmr}
        
        collection = db[rollNo]
        collection.remove( { } )
        collection.insert_one(val)
        finalJson = {"status" : "inserted"}
        
        jd = json.dumps(finalJson)
        
        return jd
    else:
        return "Post Your Request"
		
	




if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8008)
