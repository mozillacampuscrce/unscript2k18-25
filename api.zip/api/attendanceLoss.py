from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient



client = MongoClient('40.90.191.188',27017)

db = client['registration']


app = Flask(__name__)

@app.route('/notify',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
		
		
		
		
		
		return "done"
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8002)
