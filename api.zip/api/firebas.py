from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient



client = MongoClient('40.90.191.188',27017)

db = client['registration']


app = Flask(__name__)

@app.route('/notify',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        print (j) 
        rollNo = j['rollNo']
        collection = db[rollNo]
        cursor = collection.find()
        for i in cursor:
            print(i)
            tokenId = i['tokenId']
        url2 = 'https://fcm.googleapis.com/fcm/send'
        headers = {'Authorization': 'key=AIzaSyBzRcitNSR2Nxusyel6XI0o3h6nzeGoYI8', 'Content-Type': 'application/json'}
        data2 = {
                    "to" : tokenId,
                    "collapse_key" : "type_a",
                    "notification" : {
                                    "body" : "You have got a Notification",
                                    "title": "Study Buddy",
                                    "click_action":"android.intent.action.ALL_APPS"
                                    },
                    "data" : {
                            "k" : "ok"
                            
                            }
                    }
        res = requests.request("POST", url2, json=data2, headers=headers)
        print(res.text)
        
        
        
        
        return "done"
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8002)
