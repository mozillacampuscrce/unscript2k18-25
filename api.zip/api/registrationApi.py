from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient
import boto3

client = MongoClient('40.90.191.188',27017)

db = client['registration']

ses = boto3.client('ses',aws_access_key_id='AKIAISABTY7CD4SIBQRQ',
    aws_secret_access_key='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',region_name='us-west-2')
sns = boto3.client('sns',aws_access_key_id='AKIAISABTY7CD4SIBQRQ',
    aws_secret_access_key='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',region_name='us-west-2')
app = Flask(__name__)

def notify(rollNo,number,email):
	ses.send_email(
    Source="nikhil161096@gmail.com",
    Destination={
        'ToAddresses': [
            email
        ]
    },
    Message={
        'Subject': {
            'Data': 'Success',
            'Charset': 'UTF-8'
        },
        'Body': {
            'Text': {
                'Data': 'Your admission request was succesfull. your roll no is '+str(rollNo),
                'Charset': 'UTF-8'
            }
        }
    }
    )
	
	sns.publish( PhoneNumber= '+91'+number,
    Message='our admission request was succesfull. your roll no is '+str(rollNo),
    Subject='Sucess',
    MessageStructure='string',
    )
	
	
	
	
	
	
@app.route('/registration',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        
        
        
        val = db.collection_names(include_system_collections=False)
        count = 101
        for i in val:
            if i == str(count):
                count += 1
        collection = db[str(count)]
        j['rollNo'] = count
        collection.insert_one(j)
                
        
        finalJson = {"rollNo" : count}
        
        notify(count,j['no'],j['email'])
        
        jd = json.dumps(finalJson)
        
        return jd
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8015)
