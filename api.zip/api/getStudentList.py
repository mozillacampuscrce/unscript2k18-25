from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient
import datetime
client = MongoClient('40.90.191.188',27017)

db = client['attendence']

now = datetime.datetime.now()
app = Flask(__name__)

@app.route('/fillAttendance',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'POST':
        print("post")
        j = request.json
        final = []
        count = 0 
        rCount = 101
        for i in j:
            count += 1
            print(i)
            bda = i["bda"]
            snmr = i["snmr"]
            ds = i["ds"]
            cc = i["cc"]
		
            valJson = {"bda" : bda,"snmr" : snmr, "ds" : ds, "cc" : cc,"date" : now.day , "month" : str(now.strftime("%B")).lower()}
            print("test1")
            final.append(valJson)
            r = str(rCount)
            collection = db[r]
            print("test2")
            collection.insert_one(valJson)
            rCount += 1
        finalJson = {"msg" : "Attendance Filled"}
        jd = json.dumps(finalJson)
        return jd
    else:
        return "Post Your Request"
		
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8011)

		
