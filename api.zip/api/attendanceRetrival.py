from flask import Flask, request, jsonify, render_template
import requests
import json
import pymongo
from pymongo import MongoClient
from flask_cors import CORS
client = MongoClient('40.90.191.188',27017)

db = client['attendence']


app = Flask(__name__)
CORS(app)
@app.route('/Aretrieve',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'GET':
        dat = request.args.get('rollNo')
        collection = db[dat]
        db.collection_names(include_system_collections=False)
        
        cursor = collection.find({}, {'_id': False})
        count = 0
        bdaCount = 0
        ccCount = 0
        snmrCount = 0
        csmCount = 0
        attJson = []
        for i in cursor:
            print(i)
            count += 1
            attJson.append(i)
            if i['bda'] == "p":
                bdaCount += 1
            if i['cc'] == "p":
                ccCount += 1
            if i['snmr'] == "p":
                snmrCount += 1
            if i['ds'] == "p":
                csmCount += 1
        print(bdaCount,ccCount,snmrCount,csmCount,count)
        
        finalJson = {"bda" : bdaCount, "cc" : ccCount, "snmr" : snmrCount, "ds" : csmCount, "total" : count, "all" : attJson}
        jd = json.dumps(finalJson)
        print(jd)
        return jd
		
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8013)
